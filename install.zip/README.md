# F-Droid Privileged Extension Magisk Module

Reqiures Magisk 20.4+

This is an unofficial installer of the F-Droid Privileged Extension. With the power of Magisk, this is done systemlessly.
